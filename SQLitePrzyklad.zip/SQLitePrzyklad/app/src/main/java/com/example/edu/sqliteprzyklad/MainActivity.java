package com.example.edu.sqliteprzyklad;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.kludix.sqliteprzyklad.R;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    SQLiteDatabase database;
    int[] columnIndices = new int[3];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = openOrCreateDatabase("STUDENCI",MODE_PRIVATE,null);
        String sqlDB = "CREATE TABLE IF NOT EXISTS STUDENCI (Id INTEGER, Imie VARCHAR, Nazwisko VARCHAR)";
        database.execSQL(sqlDB);

        String sqlCount = "SELECT count(*) FROM STUDENCI";
        Cursor cursor = database.rawQuery(sqlCount,null);
        cursor.moveToFirst();
        int liczba = cursor.getInt(0);
        cursor.close();

        if(liczba == 0){

            String sqlStudent = "INSERT INTO STUDENCI VALUES (?,?,?)";
            SQLiteStatement statement = database.compileStatement(sqlStudent);

            statement.bindLong(1,1);
            statement.bindString(2, "Jan");
            statement.bindString(3,"Kowalski");
            statement.executeInsert();

            statement.bindLong(1,2);
            statement.bindString(2, "Anna");
            statement.bindString(3,"Nowak");
            statement.executeInsert();

        }


    }

    public void onClick(View view) {

        ArrayList<String> wyniki = new ArrayList<>();
        Cursor c = database.rawQuery("SELECT Id, Imie, Nazwisko FROM STUDENCI",null);

        if(c.moveToFirst()){

            do {
                int id = c.getInt(c.getColumnIndex("Id"));
                String imie = c.getString(c.getColumnIndex("Imie"));
                String nazwisko = c.getString(c.getColumnIndex("Nazwisko"));

                wyniki.add("Id: " + id + ", Imię: " + imie + ", Nazwisko: " + nazwisko);

            } while(c.moveToNext());
        }

        ListView listView = (ListView) findViewById(R.id.listView);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,wyniki);
        listView.setAdapter(adapter);
        c.close();


    }

    public void onClick2(View view) {

        Intent intent = new Intent(this,MainActivity2.class);
        this.startActivity(intent);


    }

}
