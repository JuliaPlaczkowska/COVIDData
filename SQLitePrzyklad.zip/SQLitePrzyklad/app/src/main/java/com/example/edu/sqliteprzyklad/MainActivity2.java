package com.example.edu.sqliteprzyklad;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.example.kludix.sqliteprzyklad.R;

public class MainActivity2 extends AppCompatActivity {

    SQLiteDatabase database;
    int[] columnIndices = new int[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        database = openOrCreateDatabase("STUDENCI", MODE_PRIVATE, null);
        String sqlDB = "CREATE TABLE IF NOT EXISTS STUDENCI (Id INTEGER, Imie VARCHAR, Nazwisko VARCHAR)";
        database.execSQL(sqlDB);


    }

    public void onClick(View view) {


        EditText et1 = (EditText) findViewById(R.id.idEditText);
        EditText et2 = (EditText) findViewById(R.id.surnameEditText);
        EditText et3 = (EditText) findViewById(R.id.nameEditText);

        int id = Integer.valueOf(et1.getText().toString());
        String imie = et2.getText().toString();
        String nazwisko = et3.getText().toString();


        String sqlStudent = "INSERT INTO STUDENCI VALUES (?,?,?)";
        SQLiteStatement statement = database.compileStatement(sqlStudent);

        statement.bindLong(1, (long) id);
        statement.bindString(2, imie);
        statement.bindString(3, nazwisko);
        statement.executeInsert();



    }


}