package com.example.edu.sqliteprzyklad;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Adapter;

import androidx.recyclerview.widget.LinearLayoutManager;
import android.support.v7.app.RecyclerView;

import com.example.kludix.sqliteprzyklad.R;

import java.util.ArrayList;

public class ShowDataActivity extends AppCompatActivity {

    ArrayList<COVIDData> data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data);

        // Lookup the recyclerview in activity layout
        RecyclerView rvData = (RecyclerView) findViewById(R.id.rvData);

        // Initialize contacts
        data = new ArrayList<>();

        for (int i = 0; i <50 ; i++) {
            data.add(new COVIDData("pol", 1, 1,1,1));
        }
        // Create adapter passing in the sample user data
        Adapter adapter = (Adapter) (new DataAdapter(data));
        // Attach the adapter to the recyclerview to populate items
        rvData.setAdapter((RecyclerView.Adapter) adapter);
        // Set layout manager to position the items
        rvData.setLayoutManager(new LinearLayoutManager(this));
    }
}