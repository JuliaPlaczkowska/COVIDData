package com.example.edu.sqliteprzyklad;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.kludix.sqliteprzyklad.R;

import java.util.ArrayList;


public class StartActivity extends AppCompatActivity {

    SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        database = openOrCreateDatabase("COVID",MODE_PRIVATE,null);
        String sqlDB = "CREATE TABLE IF NOT EXISTS COVID (country VARCHAR, cases INTEGER, active INTEGER, casesPerOneMilion INTEGER, testsPerOneMilion INTEGER)";
        database.execSQL(sqlDB);

        String sqlCount = "SELECT count(*) FROM STUDENCI";
        Cursor cursor = database.rawQuery(sqlCount,null);
        cursor.moveToFirst();
        int liczba = cursor.getInt(0);
        cursor.close();

        if(liczba == 0){

            String sqlStudent = "INSERT INTO STUDENCI VALUES (?,?,?)";
            SQLiteStatement statement = database.compileStatement(sqlStudent);

            statement.bindLong(1,1);
            statement.bindString(2, "Jan");
            statement.bindString(3,"Kowalski");
            statement.executeInsert();

            statement.bindLong(1,2);
            statement.bindString(2, "Anna");
            statement.bindString(3,"Nowak");
            statement.executeInsert();

        }
    }

    public void onShowHistory(View view){
        Intent intent = new Intent(this, ShowDataActivity.class);
        startActivity(intent);
    }


}